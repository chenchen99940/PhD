# Internship
My Internship simulation python code
